package de.simon.dankelmann.bluetoothlespam.Enums

enum class PrimaryPhy {
    PHY_LE_1M,
    PHY_LE_CODED
}