package de.simon.dankelmann.bluetoothlespam.Enums

enum class AdvertisementQueueMode {
    ADVERTISEMENT_QUEUE_MODE_LINEAR,
    ADVERTISEMENT_QUEUE_MODE_RANDOM,
    ADVERTISEMENT_QUEUE_MODE_SINGLE,
    ADVERTISEMENT_QUEUE_MODE_LIST,
}