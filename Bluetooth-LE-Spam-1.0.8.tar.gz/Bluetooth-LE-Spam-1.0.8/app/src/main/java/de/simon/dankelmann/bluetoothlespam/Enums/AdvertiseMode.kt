package de.simon.dankelmann.bluetoothlespam.Enums

enum class AdvertiseMode {
    ADVERTISEMODE_BALANCED,
    ADVERTISEMODE_LOW_LATENCY,
    ADVERTISEMODE_LOW_POWER
}