package de.simon.dankelmann.bluetoothlespam.Enums

enum class AdvertisementSetRange {
    ADVERTISEMENTSET_RANGE_UNKNOWN,
    ADVERTISEMENTSET_RANGE_CLOSE,
    ADVERTISEMENTSET_RANGE_MEDIUM,
    ADVERTISEMENTSET_RANGE_FAR
}