package de.simon.dankelmann.bluetoothlespam.Enums

enum class TxPowerLevel {
    TX_POWER_HIGH,
    TX_POWER_LOW,
    TX_POWER_MEDIUM,
    TX_POWER_ULTRA_LOW
}