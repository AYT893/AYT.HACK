package de.simon.dankelmann.bluetoothlespam.Enums

enum class SecondaryPhy {
    PHY_LE_1M,
    PHY_LE_2M,
    PHY_LE_CODED
}