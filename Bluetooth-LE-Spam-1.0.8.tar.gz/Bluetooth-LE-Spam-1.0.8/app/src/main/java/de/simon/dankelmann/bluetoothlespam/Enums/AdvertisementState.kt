package de.simon.dankelmann.bluetoothlespam.Enums

enum class AdvertisementState {
    ADVERTISEMENT_STATE_UNDEFINED,
    ADVERTISEMENT_STATE_STARTED,
    ADVERTISEMENT_STATE_SUCCEEDED,
    ADVERTISEMENT_STATE_FAILED
}